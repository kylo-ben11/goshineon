=== Replace wp-admin logo ===
Contributors: Mudit Kumawat
Tags:  wp-admin , replace logo, repalce wp-admin logo, admin logo
Donate link: http://help4cms.com/
Requires at least: 3.0
Tested up to: 4.2.4
Stable tag: 4.2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Replace wp-admin logo Plugin will help You to Replace wp-admin logo and it's easy to use and option available for manage height and width of logo.

== Description ==

Replace wp-admin logo Plugin will help You to Replace wp-admin logo and it's easy to use and option available for manage height and width of logo.

== Installation ==

1. Upload the 'replace-wp-admin-logo' folder to the '/wp-content/plugins/' directory

2. Activate the plugin through the 'Plugins' menu in WordPress

3. Show Replace wp-admin logo in Left Dashboard Menu 

4. Configure setting 

= Required Setting = 
1. In Replace wp-admin logo admin setting : Click on "Add or Upload File" Button For Upload Logo
2. In Replace wp-admin logo admin setting : Add height and width according to logo image height and width


== Screenshots ==
1. After Replace Logo wp-admin
2. Replace wp-admin logo admin setting
