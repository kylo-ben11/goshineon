<?php
class gmap_widgetControllerGmp extends controllerGmp {

}